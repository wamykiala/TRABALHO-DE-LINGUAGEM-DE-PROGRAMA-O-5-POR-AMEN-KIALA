clientes = []
fila_de_atendimento = []

#Funcão para o Registro dos Clientes
def registar_clientes():
    print("\n==*====Registro de novos clientes ==*====\n")
    nome = str(input("INFORME O NOME DO CLIENTE: \n"))
    genero = str(input("INFORME O GÉNERO DO CLIENTE (M/F): \n")).upper()

    gravida = False
    if genero == "F":
        resposta = input("A cliente encontra-se gravida? (sim/não): ").lower()
        if resposta == "sim":
            gravida = True

    idade = int(input("Informe a Idade do cliente:\n "))
    idoso = idade > 59

    resposta_def = input("O cliente possue alguma deficiência? (sim/não): \n").lower()
    deficiencia = resposta_def == "sim"

    prioridade = gravida or idoso or deficiencia

    # Compras feitas

    quantidade_d_itens = int(input("Quantos produtos o cliente vai registar? "))
    total_compras = 0

    for a in range(quantidade_d_itens):
        print(f'\n=== Produtos {a+1} de {quantidade_d_itens}')
        produto = str(input("digite o nome do Produtos: "))
        valor_item = float(input("digite o preço do produto: "))
        total_compras = total_compras + valor_item

    if total_compras > 100000:
        bonus = total_compras * 0.10
    else:
        bonus = 0

    valor_a_pagar = total_compras - bonus

    # Guarda os dados do cliete num dic
    cliente = {
        "nome": nome,
        "genero": genero,
        "total_compras": total_compras,
        "bonus": bonus,
        "valor_a_pagar": valor_a_pagar,
        "prioridade": prioridade,
        "gravida": gravida,
        "idoso": idoso,
        "deficiencia": deficiencia,
    }

    clientes.append(cliente)

    # Organização da fila de atendimento
    if prioridade:
        fila_de_atendimento.insert(0, cliente)
    else:
        fila_de_atendimento.append(cliente)

    # imprensão da Factura
    print("\n========= Fatura de Compras =========\n")
    print("Nome do Cliente:", nome)
    print(f"Total de compras Efectuadas: {total_compras} Kz")
    if bonus > 0:
        print(f" Recebeu Bónus de : -{bonus} Kz")
    else:
        print(" o cliente não  beneficiou de Bónus, a compra efectuada foi  menor que 100 000 Kz)")
    print(f"total do Valor a pagar: {valor_a_pagar}")

    if prioridade:
        print("Atendimento: Prioritário")
    else:
        print("Atendimento: Normal")


def listar_fila():
    print("\n==== Fila de atendimento (ordem de chamada) ====")
    if len(fila_de_atendimento) == 0:
        print("Não há clientes registados.")
        return

    posicao = 1
    for cliente in fila_de_atendimento:
        if cliente["prioridade"]:
            tipo = "Prioritário"
        else:
            tipo = "Normal"
        print(f"{posicao}º - {cliente['nome']} ({tipo})")
        posicao = posicao + 1


def listar_clientes():
    print("\n==== Lista de Todos os clientes registrados ====\n")
    if len(clientes) == 0:
        print("Não existem clientes já registrados.")
        return

    for cliente in clientes:
        print("-" * 30)
        print(f"Nome: {cliente['nome']}")
        print(f"Total compras: {cliente['total_compras']} Kz")
        print(f"Bónus: {cliente['bonus']}")
        print(f"Valor a pagar:{cliente['valor_a_pagar']} Kz")


# --- Menu principal do sistema ---
while True:
    print("\n=====*== SISTEMA DE FACTURAÇÂO SIBLINGS  of MOTHER ==*=====\n")
    print("1 - Registar um novo cliente:")
    print("2 - Ver a fila de atendimento:")
    print("3 - Ver a lista de todos os clientes:")
    print("4 - Sair do programa: se you again")

    opcao = input("Escolha uma das opções informadas acima:\n ")

    if opcao == "1":
        registar_clientes()
    elif opcao == "2":
        listar_fila()
    elif opcao == "3":
        listar_clientes()
    elif opcao == "4":
        break
    else:
        print("Opção inválida. Tente novamente.")